from fastapi import FastAPI
from fastapi import APIRouter, HTTPException
from database import engine, Base
from fastapi.responses import HTMLResponse

Base.metadata.create_all(bind=engine)
app = FastAPI()

main = APIRouter()

@app.get("/")
async def root():
    return {"message": "Hello World"}